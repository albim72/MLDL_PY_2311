# MovieLens 1M: trzy podejścia do tego samego zadania

Materiał szkoleniowy. **Zadanie:** przewidzieć ocenę (1–5), jaką użytkownik wystawi filmowi. Trzy podejścia, ten sam podział danych, te same metryki.

| Notebook | Podejście | Czas (CPU, 2 rdzenie) |
|---|---|---|
| `01_klasyczna_statystyka.ipynb` | testy statystyczne (Welch + FDR, bootstrap, Kruskal–Wallis, χ²) i predykcja: średnie, biasy z regularyzacją, OLS, faktoryzacja macierzy ALS | ~1,5 min |
| `02_ml_random_forest_boosting.ipynb` | feature engineering, target encoding out-of-fold, demonstracja wycieku, Random Forest, Gradient Boosting, ważność cech | ~4,5 min |
| `03_siec_neuronowa.ipynb` | PyTorch: Embedding, Linear, BatchNorm1d, ReLU, Dropout; warianty MF / MLP / hybryda (NeuMF), early stopping | ~5 min (GPU: <1 min) |
| `04_porownanie_wynikow.ipynb` | tabela i wykres wyników, analiza w segmentach (zimny start), ensemble, wyniki słuchaczy | kilka sekund |

## Uruchomienie

```
dane/movielens/users.dat
dane/movielens/ratings.dat
dane/movielens/movies.dat
```

1. Umieść pliki MovieLens 1M w `dane/movielens/` obok notebooków (ta sama ścieżka co w oryginalnej analizie).
2. `pip install -r requirements.txt` (w Google Colab wszystko jest już zainstalowane).
3. Uruchom notebooki w kolejności 01 → 02 → 03 → 04. Każdy zapisuje wyniki do `wyniki/`.

## Protokół (wspólny dla wszystkich)

* Podział deterministyczny, z haszu MD5 pary `user_id:movie_id`: ok. 72% trening, 8% walidacja, 20% test.
* **Suma kontrolna zbioru testowego: `b2290961ec`.** Musi wyjść identyczna u każdego słuchacza.
* Uczymy na treningu, hiperparametry dobieramy na walidacji, test liczymy raz.
* Metryki: RMSE (główna), MAE, ACC (trafność po zaokrągleniu).

## Wyniki referencyjne (test, 200 370 ocen)

| Model | Rodzina | RMSE | MAE |
|---|---|---|---|
| Średnia globalna | klasyczne | 1,1164 | 0,9323 |
| OLS: demografia + gatunki | klasyczne | 1,0813 | 0,8852 |
| Biasy μ + b<sub>u</sub> + b<sub>i</sub> | klasyczne | 0,9067 | 0,7158 |
| Random Forest | ML | 0,8881 | 0,7020 |
| Gradient Boosting | ML | 0,8771 | 0,6894 |
| **Biasy + ALS** | klasyczne | **0,8645** | 0,6754 |
| Sieć: MLP | NN | 0,8573 | 0,6740 |
| Sieć: MF (GMF) | NN | 0,8550 | 0,6751 |
| **Sieć: hybryda GMF + MLP** | NN | **0,8499** | 0,6661 |
| Ensemble (ALS + GB + hybryda) | — | 0,8467 | 0,6653 |

Na innym sprzęcie lub z innymi wersjami bibliotek wyniki ML/NN mogą się różnić w trzecim miejscu po przecinku.

## Wynik słuchacza

W swoim notebooku wklej komórkę nagłówkową z dowolnego notebooka 01–03, a na końcu wywołaj:

```python
zapisz_wynik('uczestnik_jan_kowalski', 'Jan K.: mój model', 'uczestnik', predykcje_na_tescie, czas_s)
```

Pliki `.json` i `.npy` z `wyniki/` wrzuć do katalogu prowadzącego i uruchom ponownie `04_porownanie_wynikow.ipynb`. Metryki zostaną przeliczone z predykcji, a wyniki z innym podziałem odrzucone.
